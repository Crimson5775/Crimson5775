import React from 'react';
import { Search } from 'lucide-react';
import { NAV_LINKS } from '../../constants/navigation';

const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 bg-navy-900/95 backdrop-blur-md border-b border-gray-800/50 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            {NAV_LINKS.map((link) => (
              <button
                key={link}
                className="text-gray-200 hover:text-orange-400 transition-colors duration-200 font-medium text-shadow"
              >
                {link}
              </button>
            ))}
          </div>
          
          <div className="relative">
            <input
              type="text"
              placeholder="Search novels..."
              className="bg-gray-800/50 text-white rounded-full py-2 pl-10 pr-4 w-64 border border-gray-700/30 focus:border-orange-400 focus:ring-1 focus:ring-orange-400 focus:outline-none"
            />
            <Search className="absolute left-3 top-2.5 text-gray-400 w-5 h-5" />
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;