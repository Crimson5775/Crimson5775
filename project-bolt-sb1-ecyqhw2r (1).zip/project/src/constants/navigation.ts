export const NAV_LINKS = ['Home', 'Browse Novels', 'Categories', 'About', 'Contact'] as const;

export const FOOTER_LINKS = {
  quickLinks: ['About Us', 'Contact', 'Terms of Service', 'Privacy Policy'],
  categories: ['Fantasy', 'Science Fiction', 'Romance', 'Mystery', 'Horror'],
  support: ['FAQ', 'Help Center', 'Report an Issue'],
} as const;

export const SOCIAL_LINKS = [
  { id: 'facebook', name: 'Facebook', href: '/facebook' },
  { id: 'twitter', name: 'Twitter', href: '/twitter' },
  { id: 'instagram', name: 'Instagram', href: '/instagram' },
  { id: 'github', name: 'GitHub', href: '/github' },
] as const;