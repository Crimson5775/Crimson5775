export interface Novel {
  title: string;
  cover: string;
  description: string;
  rating: number;
}