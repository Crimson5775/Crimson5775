import React from 'react';
import Navbar from './components/layout/Navbar';
import HeroSection from './components/home/HeroSection';
import FeaturedNovels from './components/novels/FeaturedNovels';
import Footer from './components/layout/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gray-900">
      <Navbar />
      <main className="pt-16"> {/* Add padding-top to account for fixed navbar */}
        <HeroSection />
        <FeaturedNovels />
      </main>
      <Footer />
    </div>
  );
}

export default App;