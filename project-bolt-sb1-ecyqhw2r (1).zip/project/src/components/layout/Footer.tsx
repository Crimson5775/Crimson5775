import React from 'react';
import { Facebook, Twitter, Instagram, Github } from 'lucide-react';
import { FOOTER_LINKS, SOCIAL_LINKS } from '../../constants/navigation';

const Footer = () => {
  const socialIcons = {
    facebook: Facebook,
    twitter: Twitter,
    instagram: Instagram,
    github: Github,
  };

  return (
    <footer className="bg-navy-900 border-t border-gray-800/50">
      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {FOOTER_LINKS.quickLinks.map((link) => (
                <li key={link}>
                  <a href={`/${link.toLowerCase().replace(/\s+/g, '-')}`} className="text-gray-400 hover:text-orange-400 transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Categories</h3>
            <ul className="space-y-2">
              {FOOTER_LINKS.categories.map((category) => (
                <li key={category}>
                  <a href={`/category/${category.toLowerCase().replace(/\s+/g, '-')}`} className="text-gray-400 hover:text-orange-400 transition-colors">
                    {category}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              {FOOTER_LINKS.support.map((item) => (
                <li key={item}>
                  <a href={`/support/${item.toLowerCase().replace(/\s+/g, '-')}`} className="text-gray-400 hover:text-orange-400 transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Connect With Us</h3>
            <div className="flex space-x-4">
              {SOCIAL_LINKS.map(({ id, href }) => {
                const Icon = socialIcons[id as keyof typeof socialIcons];
                return (
                  <a
                    key={id}
                    href={href}
                    className="text-gray-400 hover:text-orange-400 transition-colors"
                  >
                    <Icon className="w-6 h-6" />
                  </a>
                );
              })}
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-800/50 text-center text-gray-400 text-sm">
          © {new Date().getFullYear()} Novel Reader. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;