import React from 'react';
import { BookOpen } from 'lucide-react';

const HeroSection = () => {
  return (
    <div className="relative h-[600px] flex items-center justify-center bg-gradient-to-b from-navy-900 to-gray-900">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-10" />
      
      <div className="relative text-center px-4">
        <h1 className="text-6xl font-bold text-white mb-6 text-shadow-lg">
          Explore Worlds Beyond Imagination
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-8">
          Dive into an endless collection of captivating stories, from epic fantasies to thrilling adventures.
        </p>
        <button className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-8 py-3 rounded-full font-semibold hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg hover:shadow-orange-500/25">
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5" />
            <span>Start Reading</span>
          </div>
        </button>
      </div>
    </div>
  );
};

export default HeroSection;