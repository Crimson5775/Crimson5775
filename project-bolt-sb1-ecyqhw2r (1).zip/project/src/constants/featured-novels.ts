import { Novel } from '../types/novel';

export const FEATURED_NOVELS: Novel[] = [
  {
    title: "The Crystal Prophecy",
    cover: "https://images.unsplash.com/photo-1614544048536-0d28caf77f41?auto=format&fit=crop&q=80",
    description: "A mystical journey through ancient realms where magic and destiny intertwine.",
    rating: 4.8
  },
  {
    title: "Stellar Horizons",
    cover: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&q=80",
    description: "Explore the far reaches of space in this thrilling sci-fi adventure.",
    rating: 4.6
  },
  {
    title: "Echoes of Time",
    cover: "https://images.unsplash.com/photo-1516541196182-6bdb0516ed27?auto=format&fit=crop&q=80",
    description: "A timeless romance that spans centuries and defies the laws of nature.",
    rating: 4.9
  }
];